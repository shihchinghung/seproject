window.onload = function(){hide_all(); };


function child1()
{
    var obj = document.getElementById('child1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function aa1()
{
    var obj = document.getElementById('aa1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function t1()
{
    var obj = document.getElementById('t1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function t2()
{
    var obj = document.getElementById('t2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function t3()
{
    var obj = document.getElementById('t3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function aa2()
{
    var obj = document.getElementById('aa2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function aa3()
{
    var obj = document.getElementById('aa3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function aa4()
{
    var obj = document.getElementById('aa4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function aa5()
{
    var obj = document.getElementById('aa5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function bb1()
{
    var obj = document.getElementById('bb1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function bb2()
{
    var obj = document.getElementById('bb2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function bb3()
{
    var obj = document.getElementById('bb3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function bb4()
{
    var obj = document.getElementById('bb4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function bb5()
{
    var obj = document.getElementById('bb5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function cc1()
{
    var obj = document.getElementById('cc1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function cc2()
{
    var obj = document.getElementById('cc2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function cc3()
{
    var obj = document.getElementById('cc3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function cc4()
{
    var obj = document.getElementById('cc4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function cc5()
{
    var obj = document.getElementById('cc5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function dd1()
{
    var obj = document.getElementById('dd1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function dd2()
{
    var obj = document.getElementById('dd2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function dd3()
{
    var obj = document.getElementById('dd3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function dd4()
{
    var obj = document.getElementById('dd4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function dd5()
{
    var obj = document.getElementById('dd5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function ee1()
{
    var obj = document.getElementById('ee1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ee2()
{
    var obj = document.getElementById('ee2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ee3()
{
    var obj = document.getElementById('ee3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ee4()
{
    var obj = document.getElementById('ee4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ee5()
{
    var obj = document.getElementById('ee5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function ff1()
{
    var obj = document.getElementById('ff1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ff2()
{
    var obj = document.getElementById('ff2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ff3()
{
    var obj = document.getElementById('ff3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ff4()
{
    var obj = document.getElementById('ff4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ff5()
{
    var obj = document.getElementById('ff5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function gg1()
{
    var obj = document.getElementById('gg1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function gg2()
{
    var obj = document.getElementById('gg2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function gg3()
{
    var obj = document.getElementById('gg3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function gg4()
{
    var obj = document.getElementById('gg4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function gg5()
{
    var obj = document.getElementById('gg5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function hh1()
{
    var obj = document.getElementById('hh1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function hh2()
{
    var obj = document.getElementById('hh2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function hh3()
{
    var obj = document.getElementById('hh3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function hh4()
{
    var obj = document.getElementById('hh4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function hh5()
{
    var obj = document.getElementById('hh5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function ii1()
{
    var obj = document.getElementById('ii1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ii2()
{
    var obj = document.getElementById('ii2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ii3()
{
    var obj = document.getElementById('ii3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ii4()
{
    var obj = document.getElementById('ii4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ii5()
{
    var obj = document.getElementById('ii5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function jj1()
{
    var obj = document.getElementById('jj1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function jj2()
{
    var obj = document.getElementById('jj2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function jj3()
{
    var obj = document.getElementById('jj3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function jj4()
{
    var obj = document.getElementById('jj4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function jj5()
{
    var obj = document.getElementById('jj5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function kk1()
{
    var obj = document.getElementById('kk1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function kk2()
{
    var obj = document.getElementById('kk2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function kk3()
{
    var obj = document.getElementById('kk3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function kk4()
{
    var obj = document.getElementById('kk4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function kk5()
{
    var obj = document.getElementById('kk5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function ll1()
{
    var obj = document.getElementById('ll1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ll2()
{
    var obj = document.getElementById('ll2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ll3()
{
    var obj = document.getElementById('ll3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ll4()
{
    var obj = document.getElementById('ll4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function ll5()
{
    var obj = document.getElementById('ll5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function mm1()
{
    var obj = document.getElementById('mm1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function mm2()
{
    var obj = document.getElementById('mm2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function mm3()
{
    var obj = document.getElementById('mm3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function mm4()
{
    var obj = document.getElementById('mm4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function mm5()
{
    var obj = document.getElementById('mm5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function nn1()
{
    var obj = document.getElementById('nn1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function nn2()
{
    var obj = document.getElementById('nn2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function nn3()
{
    var obj = document.getElementById('nn3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function nn4()
{
    var obj = document.getElementById('nn4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function nn5()
{
    var obj = document.getElementById('nn5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function oo1()
{
    var obj = document.getElementById('oo1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function oo2()
{
    var obj = document.getElementById('oo2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function oo3()
{
    var obj = document.getElementById('oo3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function oo4()
{
    var obj = document.getElementById('oo4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function oo5()
{
    var obj = document.getElementById('oo5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function pp1()
{
    var obj = document.getElementById('pp1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function pp2()
{
    var obj = document.getElementById('pp2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function pp3()
{
    var obj = document.getElementById('pp3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function pp4()
{
    var obj = document.getElementById('pp4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function pp5()
{
    var obj = document.getElementById('pp5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function qq1()
{
    var obj = document.getElementById('qq1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function qq2()
{
    var obj = document.getElementById('qq2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function qq3()
{
    var obj = document.getElementById('qq3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function qq4()
{
    var obj = document.getElementById('qq4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function qq5()
{
    var obj = document.getElementById('qq5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function rr1()
{
    var obj = document.getElementById('rr1');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function rr2()
{
    var obj = document.getElementById('rr2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function rr3()
{
    var obj = document.getElementById('rr3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function rr4()
{
    var obj = document.getElementById('rr4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function rr5()
{
    var obj = document.getElementById('rr5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function child2()
{
    var obj = document.getElementById('child2');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function child3()
{
    var obj = document.getElementById('child3');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child4()
{
    var obj = document.getElementById('child4');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child5()
{
    var obj = document.getElementById('child5');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child6()
{
    var obj = document.getElementById('child6');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child7()
{
    var obj = document.getElementById('child7');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child8()
{
    var obj = document.getElementById('child8');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child9()
{
    var obj = document.getElementById('child9');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child10()
{
    var obj = document.getElementById('child10');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child11()
{
    var obj = document.getElementById('child11');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child12()
{
    var obj = document.getElementById('child12');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child13()
{
    var obj = document.getElementById('child13');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child14()
{
    var obj = document.getElementById('child14');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child15()
{
    var obj = document.getElementById('child15');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child16()
{
    var obj = document.getElementById('child16');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child17()
{
    var obj = document.getElementById('child17');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}
function child18()
{
    var obj = document.getElementById('child18');

    if (obj.style.display =='none')
    {
        obj.style.display = 'block';
    }
    else{
        obj.style.display = 'none';
    }
}

function hide_all()
{
    document.getElementById('child1').style.display = 'none';
    document.getElementById('child2').style.display = 'none';
    document.getElementById('child3').style.display = 'none';
    document.getElementById('child4').style.display = 'none';
    document.getElementById('child5').style.display = 'none';
    document.getElementById('child6').style.display = 'none';
    document.getElementById('child7').style.display = 'none';
    document.getElementById('child8').style.display = 'none';
    document.getElementById('child9').style.display = 'none';
    document.getElementById('child10').style.display = 'none';
    document.getElementById('child11').style.display = 'none';
    document.getElementById('child12').style.display = 'none';
    document.getElementById('child13').style.display = 'none';
    document.getElementById('child14').style.display = 'none';
    document.getElementById('child15').style.display = 'none';
    document.getElementById('child16').style.display = 'none';
    document.getElementById('child17').style.display = 'none';
    document.getElementById('child18').style.display = 'none';
    document.getElementById('aa1').style.display = 'none';
    document.getElementById('aa2').style.display = 'none';
    document.getElementById('aa3').style.display = 'none';
    document.getElementById('aa4').style.display = 'none';
    document.getElementById('aa5').style.display = 'none';
    document.getElementById('bb1').style.display = 'none';
    document.getElementById('bb2').style.display = 'none';
    document.getElementById('bb3').style.display = 'none';
    document.getElementById('bb4').style.display = 'none';
    document.getElementById('bb5').style.display = 'none';
    document.getElementById('cc1').style.display = 'none';
    document.getElementById('cc2').style.display = 'none';
    document.getElementById('cc3').style.display = 'none';
    document.getElementById('cc4').style.display = 'none';
    document.getElementById('cc5').style.display = 'none';
    document.getElementById('dd1').style.display = 'none';
    document.getElementById('dd2').style.display = 'none';
    document.getElementById('dd3').style.display = 'none';
    document.getElementById('dd4').style.display = 'none';
    document.getElementById('dd5').style.display = 'none';
    document.getElementById('ee1').style.display = 'none';
    document.getElementById('ee2').style.display = 'none';
    document.getElementById('ee3').style.display = 'none';
    document.getElementById('ee4').style.display = 'none';
    document.getElementById('ee5').style.display = 'none';
    document.getElementById('ff1').style.display = 'none';
    document.getElementById('ff2').style.display = 'none';
    document.getElementById('ff3').style.display = 'none';
    document.getElementById('ff4').style.display = 'none';
    document.getElementById('ff5').style.display = 'none';
    document.getElementById('gg1').style.display = 'none';
    document.getElementById('gg2').style.display = 'none';
    document.getElementById('gg3').style.display = 'none';
    document.getElementById('gg4').style.display = 'none';
    document.getElementById('gg5').style.display = 'none';
    document.getElementById('hh1').style.display = 'none';
    document.getElementById('hh2').style.display = 'none';
    document.getElementById('hh3').style.display = 'none';
    document.getElementById('hh4').style.display = 'none';
    document.getElementById('hh5').style.display = 'none';
    document.getElementById('ii1').style.display = 'none';
    document.getElementById('ii2').style.display = 'none';
    document.getElementById('ii3').style.display = 'none';
    document.getElementById('ii4').style.display = 'none';
    document.getElementById('ii5').style.display = 'none';
    document.getElementById('jj1').style.display = 'none';
    document.getElementById('jj2').style.display = 'none';
    document.getElementById('jj3').style.display = 'none';
    document.getElementById('jj4').style.display = 'none';
    document.getElementById('jj5').style.display = 'none';
    document.getElementById('kk1').style.display = 'none';
    document.getElementById('kk2').style.display = 'none';
    document.getElementById('kk3').style.display = 'none';
    document.getElementById('kk4').style.display = 'none';
    document.getElementById('kk5').style.display = 'none';
    document.getElementById('ll1').style.display = 'none';
    document.getElementById('ll2').style.display = 'none';
    document.getElementById('ll3').style.display = 'none';
    document.getElementById('ll4').style.display = 'none';
    document.getElementById('ll5').style.display = 'none';
    document.getElementById('mm1').style.display = 'none';
    document.getElementById('mm2').style.display = 'none';
    document.getElementById('mm3').style.display = 'none';
    document.getElementById('mm4').style.display = 'none';
    document.getElementById('mm5').style.display = 'none';
    document.getElementById('nn1').style.display = 'none';
    document.getElementById('nn2').style.display = 'none';
    document.getElementById('nn3').style.display = 'none';
    document.getElementById('nn4').style.display = 'none';
    document.getElementById('nn5').style.display = 'none';
    document.getElementById('oo1').style.display = 'none';
    document.getElementById('oo2').style.display = 'none';
    document.getElementById('oo3').style.display = 'none';
    document.getElementById('oo4').style.display = 'none';
    document.getElementById('oo5').style.display = 'none';
    document.getElementById('pp1').style.display = 'none';
    document.getElementById('pp2').style.display = 'none';
    document.getElementById('pp3').style.display = 'none';
    document.getElementById('pp4').style.display = 'none';
    document.getElementById('pp5').style.display = 'none';
    document.getElementById('qq1').style.display = 'none';
    document.getElementById('qq2').style.display = 'none';
    document.getElementById('qq3').style.display = 'none';
    document.getElementById('qq4').style.display = 'none';
    document.getElementById('qq5').style.display = 'none';
    document.getElementById('rr1').style.display = 'none';
    document.getElementById('rr2').style.display = 'none';
    document.getElementById('rr3').style.display = 'none';
    document.getElementById('rr4').style.display = 'none';
    document.getElementById('rr5').style.display = 'none';
    document.getElementById('t1').style.display = 'none';
    document.getElementById('t2').style.display = 'none';
    document.getElementById('t3').style.display = 'none';

}




function changeColor1(){
    document.getElementById("wh").style.background='#B09FDC';
}
function changeColor2(){
    document.getElementById("cj").style.background='#B09FDC';
}
function changeColor3(){
    document.getElementById("ta").style.background='#B09FDC';
}
function changeColor4(){
    document.getElementById("xi").style.background='#B09FDC';
}
function changeColor5(){
    document.getElementById("ng").style.background='#B09FDC';
}
function changeColor6(){
    document.getElementById("ws").style.background='#B09FDC';
}
function changeColor7(){
    document.getElementById("dt").style.background='#B09FDC';
}
function changeColor8(){
    document.getElementById("cs").style.background='#B09FDC';
}
function changeColor9(){
    document.getElementById("ss").style.background='#B09FDC';
}
function changeColor10(){
    document.getElementById("nh").style.background='#B09FDC';
}
function changeColor11(){
    document.getElementById("bt").style.background='#B09FDC';
}
function changeColor12(){
    document.getElementById("sl").style.background='#B09FDC';
}


function baby(){
    document.getElementById("baby").style.background='#B09FDC';
}
function child(){
    document.getElementById("child").style.background='#B09FDC';
}
function adolo(){
    document.getElementById("adolo").style.background='#B09FDC';
}


function b1(){
    document.getElementById("b1").style.background='#B09FDC';
}
function b2(){
    document.getElementById("b2").style.background='#B09FDC';
}
function b3(){
    document.getElementById("b3").style.background='#B09FDC';
}
function b4(){
    document.getElementById("b4").style.background='#B09FDC';
}
function b5(){
    document.getElementById("b5").style.background='#B09FDC';
}
function b6(){
    document.getElementById("b6").style.background='#B09FDC';
}
function b7(){
    document.getElementById("b7").style.background='#B09FDC';
}
function b8(){
    document.getElementById("b8").style.background='#B09FDC';
}
function b9(){
    document.getElementById("b9").style.background='#B09FDC';
}

function f1(){
    document.getElementById("f1").style.background='#B09FDC';
}
function f2(){
    document.getElementById("f2").style.background='#B09FDC';
}
function f3(){
    document.getElementById("f3").style.background='#B09FDC';
}

function g1(){
    document.getElementById("g1").style.background='#B09FDC';
}
function g2(){
    document.getElementById("g2").style.background='#B09FDC';
}
function g3(){
    document.getElementById("g3").style.background='#B09FDC';
}

function h1(){
    document.getElementById("h1").style.background='#B09FDC';
}
function h2(){
    document.getElementById("h2").style.background='#B09FDC';
}
function h3(){
    document.getElementById("h3").style.background='#B09FDC';
}

function i1(){
    document.getElementById("i1").style.background='#B09FDC';
}
function i2(){
    document.getElementById("i2").style.background='#B09FDC';
}
function i3(){
    document.getElementById("i3").style.background='#B09FDC';
}





function c1(){
    document.getElementById("c1").style.background='#B09FDC';
}
function c2(){
    document.getElementById("c2").style.background='#B09FDC';
}
function c3(){
    document.getElementById("c3").style.background='#B09FDC';
}
function c4(){
    document.getElementById("c4").style.background='#B09FDC';
}
function c5(){
    document.getElementById("c5").style.background='#B09FDC';
}
function c6(){
    document.getElementById("c6").style.background='#B09FDC';
}
function c7(){
    document.getElementById("c7").style.background='#B09FDC';
}
function c8(){
    document.getElementById("c8").style.background='#B09FDC';
}
function c9(){
    document.getElementById("c9").style.background='#B09FDC';
}


function aa_1(){
    document.getElementById("a1").style.background='#B09FDC';
}
function aa_2(){
    document.getElementById("a2").style.background='#B09FDC';
}
function aa_3(){
    document.getElementById("a3").style.background='#B09FDC';
}


function a4(){
    document.getElementById("a4").style.background='#B09FDC';
}
function a5(){
    document.getElementById("a5").style.background='#B09FDC';
}
function a6(){
    document.getElementById("a6").style.background='#B09FDC';
}
function a7(){
    document.getElementById("a7").style.background='#B09FDC';
}
function a8(){
    document.getElementById("a8").style.background='#B09FDC';
}
function a9(){
    document.getElementById("a9").style.background='#B09FDC';
}

function d1(){
    document.getElementById("d1").style.background='#B09FDC';
}
function d2(){
    document.getElementById("d2").style.background='#B09FDC';
}
function d3(){
    document.getElementById("d3").style.background='#B09FDC';
}
function d4(){
    document.getElementById("d4").style.background='#B09FDC';
}
function d5(){
    document.getElementById("d5").style.background='#B09FDC';
}
function d6(){
    document.getElementById("d6").style.background='#B09FDC';
}
function d7(){
    document.getElementById("d7").style.background='#B09FDC';
}
function d8(){
    document.getElementById("d8").style.background='#B09FDC';
}
function d9(){
    document.getElementById("d9").style.background='#B09FDC';
}

function e1(){
    document.getElementById("e1").style.background='#B09FDC';
}
function e2(){
    document.getElementById("e2").style.background='#B09FDC';
}
function e3(){
    document.getElementById("e3").style.background='#B09FDC';
}
function e4(){
    document.getElementById("e4").style.background='#B09FDC';
}
function e5(){
    document.getElementById("e5").style.background='#B09FDC';
}
function e6(){
    document.getElementById("e6").style.background='#B09FDC';
}
function e7(){
    document.getElementById("e7").style.background='#B09FDC';
}
function e8(){
    document.getElementById("e8").style.background='#B09FDC';
}
function e9(){
    document.getElementById("e9").style.background='#B09FDC';
}


function a(){
    document.getElementById("a").style.background='#B09FDC';
}

function b(){
    document.getElementById("b").style.background='#B09FDC';
}

function e(){
    document.getElementById("e").style.background='#B09FDC';
}

function s(){
    document.getElementById("s").style.background='#B09FDC';
}

function h(){
    document.getElementById("h").style.background='#B09FDC';
}

function l(){
    document.getElementById("l").style.background='#B09FDC';
}
